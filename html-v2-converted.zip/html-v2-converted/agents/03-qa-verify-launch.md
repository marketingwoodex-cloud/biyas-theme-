# Agent 03 — QA, Verification and Launch Readiness

## Scope
Final QA and launch-readiness audit. This agent does not approve publication where required source/rights/form/runtime evidence is absent.

## Required checks
- [ ] Desktop/mobile navigation and responsive layouts.
- [ ] Form validation, private-viewing, trade and Request Price paths.
- [ ] WhatsApp action only after official number approval.
- [ ] Keyboard navigation, focus states and colour contrast.
- [ ] Alt text/captions, reduced motion and image optimisation.
- [ ] Page titles, metadata, canonicals, OG images, sitemap, robots and structured-data plan.
- [ ] Internal links, 404, privacy, terms, copyright, commission, delivery and returns.
- [ ] Spam protection, analytics consent and backup plan.
- [ ] Placeholder-art and unverified-claim audit.

## Launch report format
Every issue must include route, issue, evidence, priority (P0/P1/P2), owner and fix recommendation.

## Known P0 baseline
- Legacy brand names are inconsistent.
- Founder spelling is not fully approved.
- Legacy Third Art archive uses repeated placeholder/cropped media.
- Punjabi Verha, Library and Media/Press need verified records.
- Static HTML is not a WordPress migration.

**Production approval is not granted until all P0 findings are closed.**