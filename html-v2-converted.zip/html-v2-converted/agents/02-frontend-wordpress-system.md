# Agent 02 — Frontend and WordPress System

## Scope
Owns global Header/Footer, final navigation, reusable frontend templates, responsive layout, WordPress migration plan, CPTs/fields/taxonomies, URLs, enquiry paths, forms, accessibility and reduced-motion support.

## Current HTML V2 rule
This folder is a **standalone HTML V2 website**. Do not perform WordPress migration or conversion work unless separately authorised.

## Requirements
- Preserve strong cinematic hierarchy where it supports the brand, but favour trust, accurate data and usable navigation over animation.
- Use one approved brand name and one navigation structure.
- Pending archive pages use clear holding states and enquiry CTAs.
- Originals/Third Art remain enquiry-only; no checkout.
- No invented biography/cultural claims, no repeated folio imagery and no content marked unverified by Agent 01.
- Future WordPress build: Containers/native widgets, XPRO Header/Footer, WPForms forms, keyboard support and reduced motion.

## Template families required
Artworks, Collections, Artists, Exhibitions/Events, Projects, Books, Punjabi Verha Events, Press and Journal Articles.

## Acceptance
- Navigation works at 360px, 768px and desktop.
- Menus are keyboard accessible; Escape closes dropdowns.
- Future galleries/drawers/lightboxes must be keyboard accessible.
- Static HTML V2 must not be described as a converted WordPress theme.