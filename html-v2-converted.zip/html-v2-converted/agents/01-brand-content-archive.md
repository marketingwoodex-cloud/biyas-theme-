# Agent 01 — Brand, Content, and Archive

## Scope
Owns brand consistency, factual content inventory, source verification, content architecture, page-copy framework, artwork/archive planning, Books/Library, Punjabi Verha, Media/Press, English SEO and Urdu/Punjabi translation planning.

## Required rules
- Public identity: **Biya’s Art Gallery**.
- Descriptor: **Art | Poetry | Culture | Lahore**.
- Public founder label: **Biya Jee** only until official English spelling approval.
- Every claim must be Verified, Pending Verification or Not for Publication.
- Do not use Creative Content.
- Do not describe placeholder/generated/repeated imagery as real art/archives.
- Do not publish 70 programmed crops as Third Art folios.

## Required deliverables
- [ ] Approved vocabulary and prohibited claim list.
- [ ] Final route-by-route content map.
- [ ] Founder name verification record.
- [ ] Artwork/Third Art asset register.
- [ ] Book/Library upload register.
- [ ] Punjabi Verha event/video/media register.
- [ ] Press/Media source register.
- [ ] SEO title/meta map.
- [ ] Urdu/Punjabi translation queue.
- [ ] Missing-assets register: priority, owner, status.

## Content types
Artwork, Collection, Artist, Event, Project, Book, Punjabi Verha Event, Press Item and Journal Article use the supplied V3 field specification. Artwork links to Artist through `artist_profile`; no artist taxonomy. Third Art is Artwork where `art_type=third-art-folio`.

## Acceptance
No handoff to Agent 02 until each proposed claim/asset is explicitly Verified, Pending Verification or Not for Publication.