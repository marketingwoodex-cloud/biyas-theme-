# Agent 01 — HTML V2 Content Handoff Register

**Status:** Phase 1 started.  
**Scope:** brand/content/archive planning only. No static frontend source file was edited by Agent 01.

## Approved public vocabulary

- Biya’s Art Gallery
- Art | Poetry | Culture | Lahore
- Biya Jee
- Not decoration. A presence.
- Request Details
- Request Price
- Arrange a Private Viewing
- Punjabi Verha
- Books and Library
- Exhibitions and Events

## Prohibited or source-dependent language

- Creative Content
- Art & Craft as current primary identity
- Public full founder name before approval
- Pakistan’s first / museum / national asset / awards / records without evidence
- Available / original / sold / certified / archived unless record evidence supports it
- Any claim that one image creates 70 distinct Third Art folios

## Route content status

| Route family | Current HTML V2 content state | Agent 01 approval |
|---|---|---|
| Home | Brand framework / holding states | Approved static framework |
| Artworks / Collections / Artists | Holding state | No records approved |
| Third Art | Controlled holding state | No folios approved |
| Biya Jee / Poetry / Media | Public name rule and source-dependent copy | Use Biya Jee only |
| Punjabi Verha | Independent pillar holding state | No programme records approved |
| Events | Holding state | No Event records approved |
| Projects / Books / Press | Holding state | No records approved |
| Commissions / Trade / Visit | Framework/CTA copy | Contact/form destinations pending |
| Legal / Guide | Framework only | Approved legal/policy text pending |

## Required owner content before a future content population phase

1. Verified artwork catalogue and rights-approved media.
2. Distinct Third Art folios, translations, rights and verification data.
3. Verified founder biography and official English naming approval.
4. Punjabi Verha programme/event/video/media register.
5. Book/library bibliography, covers and excerpt permissions.
6. Verified project and press source data.
7. Official contact/WhatsApp details and approved form inbox.
8. Approved legal, privacy, delivery, returns and commission text.

## Handoff result

HTML V2 may continue with its neutral static structure. It must not be populated with unverified record-level content.
