# Biya’s Art Gallery — HTML V2

**Type:** standalone HTML V2 website.  
**Current scope:** static HTML, CSS, JavaScript, content architecture and agent plans only. No WordPress files, migration work or conversion work is included.

## Run preview
Open `index.html` from a static server.

## Navigation
The final proposed navigation is implemented consistently across all 24 static route pages, including Artworks, Biya Jee and Punjabi Verha disclosure menus.

## File structure
- `*.html` — standalone static route pages
- `style.css` — shared no-external-dependency HTML V2 styles
- `app.js` — mobile menu and keyboard-accessible dropdown interactions
- `CONTENT_TYPES.md` — WordPress-ready content planning reference for future planning only
- `agents/` — Phase 1, Phase 2 and Phase 3 agent briefs

## Content policy
All pages use neutral holding-state content. No legacy/generated asset was copied to this new folder. Do not represent this static HTML V2 website as a conversion or use it to publish artwork/archive claims without verification.
