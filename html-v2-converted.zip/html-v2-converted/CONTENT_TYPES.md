# Required Content Types — HTML V2 Planning Reference

## Artwork
Title; Artist; Collection; Medium; Year; Dimensions; Availability; Price Policy; Images; Artwork Story; Certificate/Provenance Status; Verification Status.

## Collection
Title; Curatorial Statement; Hero Image; Related Artworks; Featured Artist; CTA.

## Artist
Biography; Portrait; Practice; Selected Works; Exhibitions; Press; Enquiry CTA.

## Exhibition or Event
Title; Date; Venue; Artists/Guests; Programme; Description; Photos; Video; Press Coverage; RSVP/Enquiry CTA. Required Event Type: exhibition, mushaira, muqalma, talk, private-viewing or other.

## Project or Installation
Title; Statement; Year; Real Images; Documentation; Media Coverage; Source Status; Collector/Institutional Enquiry CTA.

## Book or Library Item
Title; Author; Cover; Publication Year; Language; Synopsis; Approved Excerpt; Availability; Purchase/Enquiry CTA.

## Punjabi Verha Event
Programme Title; Guest; Date; Venue; Images; Video; Media Coverage; RSVP/Collaboration CTA.

## Press or Media Item
Outlet; Date; Source URL; Thumbnail; Verified Summary; Related Page/Project.

## Governing implementation notes
- Third Art folios are Artwork records where `art_type=third-art-folio`.
- Artwork Artist is `artist_profile`, a relationship to Artist; not a taxonomy.
- `artwork_collection` is the Artwork collection taxonomy/public label Collection.
- All public media/claims require Verified status and approved rights.
