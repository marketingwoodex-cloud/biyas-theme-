# Biya’s Art Gallery — HTML V2 Master Plan

## Scope
Build and review a standalone HTML V2 website with the final navigation, a consistent visual system, neutral content holding states and agent-based content/QA governance.

**Excluded from this phase:** WordPress implementation, Elementor/XPRO configuration, migration, production publishing, real media import and unverified catalogue/event/archive data.

## Navigation
- Home
- Artworks: Available Works, Collections, The Third Art, Archive / Sold Works, Gallery Artists
- Biya Jee: Biography, Art and Installations, Poetry and Writing, Books and Library, Media and Interviews
- Punjabi Verha: About Punjabi Verha, Monthly Events, Mushairas, Muqalma and Dialogues, Video Archive, Media Coverage, Join / Collaborate
- Exhibitions and Events
- Projects and Interiors
- Commissions and Custom Studio
- Trade and Hospitality
- Media and Press
- Visit / Contact

## Development phases

### Stage 1 — Agent 01: Brand, Content and Archive
Owns brand rules, source verification, content types, asset registers, page-copy framework, SEO planning and translation queue. Does not edit HTML/CSS/JS production frontend.

### Stage 2 — Agent 02: Frontend and System Plan
Owns consistent static Header/Footer/navigation, reusable HTML sections, responsive behaviour, accessibility and a future migration/system plan. Does not perform migration/conversion in HTML V2.

### Stage 3 — Agent 03: QA, Verify and Test
Owns HTML V2 navigation/responsive/accessibility/content-status audit and produces P0/P1/P2 reports with route, evidence, owner and recommendation.

## Content rule
Every public claim/media item is Verified, Pending Verification or Not for Publication. HTML V2 uses holding states instead of fabricated artwork, folio, event, library, press or biography records.

## Acceptance for HTML V2
- One name and navigation system across all pages.
- Responsive navigation works at 360px, 768px and desktop.
- Dropdown navigation is keyboard accessible and Escape closes it.
- All pages preserve independent Artworks, Biya Jee, Punjabi Verha, Library, Press and Events pillars.
- No generated legacy hero/media or programmed 70-folio archive is carried into HTML V2.
