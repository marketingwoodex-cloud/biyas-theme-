# Biya’s Art Gallery V3 — Start Here

This directory is the V3 package workspace. It contains the plan and the required delivery folders but no unverified media/content.

Do not treat the existing V2 skeleton import as the V3 completed visual demo. V3 will be built and tested in two paths:
- Option A: OCDI safe-draft import.
- Option B: manual recovery/import, file by file.

Read `00-master-plan/MASTER_PLAN_V3.md` before adding or importing anything.
