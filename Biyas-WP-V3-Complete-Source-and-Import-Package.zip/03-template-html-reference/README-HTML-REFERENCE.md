# V3 HTML Reference

These HTML files are visual specifications for Elementor implementation. They must never be inserted into Elementor with an HTML widget. Translate their hierarchy into Containers and native Elementor widgets. The documents contain no media and use governed holding states.
