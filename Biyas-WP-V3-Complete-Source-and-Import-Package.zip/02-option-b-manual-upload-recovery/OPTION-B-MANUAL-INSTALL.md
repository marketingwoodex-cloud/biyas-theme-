# Option B — Manual Recovery

Use this only if OCDI fails. Upload theme and Master Plugin. Import one JSON file at a time from `elementor-json`, starting with `home.json`. Keep a screenshot and result in the import test log. Import the WXR only after theme/plugin/Elementor activation. Build XPRO Header/Footer manually using the maps in `xpro-source-layouts`.
