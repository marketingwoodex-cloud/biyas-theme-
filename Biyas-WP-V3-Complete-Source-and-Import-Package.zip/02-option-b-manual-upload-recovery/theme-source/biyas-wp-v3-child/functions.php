<?php
if (!defined('ABSPATH')) exit;
add_action('wp_enqueue_scripts',function(){wp_enqueue_style('biyas-wp-v3-child',get_stylesheet_uri(),['biyas-wp'],'3.0.0');},20);
