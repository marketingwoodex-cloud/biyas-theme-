<?php
if (!defined('ABSPATH')) exit;
add_action('after_setup_theme',function(){add_theme_support('title-tag');add_theme_support('post-thumbnails');register_nav_menus(['primary'=>__('Primary Menu','biyas-wp'),'footer'=>__('Footer Menu','biyas-wp')]);});
add_action('wp_enqueue_scripts',function(){wp_enqueue_style('biyas-wp',get_stylesheet_uri(),[], '2.0.0');});
add_action('customize_register',function($c){$c->add_section('biya_contact',['title'=>"Biya Gallery Contact"]);$c->add_setting('biya_whatsapp',['sanitize_callback'=>'sanitize_text_field']);$c->add_control('biya_whatsapp',['section'=>'biya_contact','label'=>'Official WhatsApp (international digits only)','type'=>'text']);});
add_action('wp_footer',function(){$n=preg_replace('/\D/','',get_theme_mod('biya_whatsapp',''));if($n)echo '<a class="biya-cta biya-whatsapp" href="https://wa.me/'.esc_attr($n).'" rel="noopener" target="_blank">Enquire on WhatsApp</a>';});
require_once get_template_directory() . '/inc/ocdi.php';
