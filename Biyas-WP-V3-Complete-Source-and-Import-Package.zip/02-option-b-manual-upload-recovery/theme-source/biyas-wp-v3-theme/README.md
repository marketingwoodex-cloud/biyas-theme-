# Biya’s WP V3 Parent Theme

Standalone WordPress theme for the V3 safe-draft foundation. It includes the visual token CSS, an accessible fallback header/footer, menu locations, disabled-by-default WhatsApp configuration and OCDI demo registration.

The fallback header/footer are intentionally replaced only after XPRO global templates are manually configured. Do not activate the optional child theme during the initial import.
