<?php
/** OCDI integration. OCDI is optional and may be deleted after verified import. */
if (!defined('ABSPATH')) exit;
add_filter('ocdi/import_files', function () {
    return [[
        'import_file_name'           => "Biya’s WP — V3 Safe Draft Foundation",
        'categories'                 => ['Biya Gallery', 'Safe Draft'],
        'local_import_file'          => get_template_directory() . '/demo-content/biya-v3-safe-draft-demo.xml',
        'import_preview_image_url'   => '',
        'preview_url'                => '',
    ]];
});
/** Create an unassigned draft-site menu after OCDI content import; never sets homepage or publishes pages. */
add_action('ocdi/after_import', function () {
    $menu_name = "Biya Gallery Draft Navigation";
    $menu = wp_get_nav_menu_object($menu_name);
    $menu_id = $menu ? $menu->term_id : wp_create_nav_menu($menu_name);
    if (is_wp_error($menu_id)) return;
    foreach (['home'=>'Home','artworks'=>'Artworks','the-third-art'=>'The Third Art','biya-jee'=>'Biya Jee','punjabi-verha'=>'Punjabi Verha','events'=>'Events','visit-contact'=>'Visit / Contact'] as $slug=>$label) {
        $page = get_page_by_path($slug);
        if ($page) wp_update_nav_menu_item($menu_id, 0, ['menu-item-title'=>$label,'menu-item-object-id'=>$page->ID,'menu-item-object'=>'page','menu-item-type'=>'post_type','menu-item-status'=>'publish']);
    }
    set_theme_mod('biya_ocdi_import_complete', current_time('mysql'));
}, 20);
