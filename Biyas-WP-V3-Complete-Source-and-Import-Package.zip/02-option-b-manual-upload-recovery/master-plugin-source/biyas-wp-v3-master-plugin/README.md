# Biya's WP Master Plugin
Single required companion plugin. It replaces separate CPT, ACF and Elementor installer packages.

It uses native WP metaboxes (not ACF), creates drafts only, and detects Elementor/XPRO. It never bundles XPRO/Elementor, invents content or publishes a demo.
