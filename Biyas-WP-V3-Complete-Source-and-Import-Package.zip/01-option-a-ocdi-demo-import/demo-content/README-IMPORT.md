# OCDI Safe Draft Demo

OCDI reads `biya-safe-draft-demo.xml` through the theme’s `ocdi/import_files` hook. It creates **Draft** pages only, preserving editable Elementor Container data. No art assets, real artworks, contact details or XPRO assignment are included.

Do not delete OCDI until import verification is complete. Deleting OCDI after a successful import does not remove imported posts or post metadata.
