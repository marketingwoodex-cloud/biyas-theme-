# Option A — OCDI Safe Draft Import

1. Backup and use staging.
2. Upload/activate `biyas-wp-v3-theme.zip` and `biyas-wp-v3-master-plugin.zip`.
3. Install Elementor Free, then temporarily install One Click Demo Import.
4. Appearance → Import Demo Data → **Biya’s WP — Safe Draft Foundation** → Continue & Import. Ignore OCDI generic commercial-plugin recommendations.
5. Verify imported pages are Draft and Elementor layouts are editable.
6. Install/configure XPRO manually using `05-xpro-manual`.
7. Configure WPForms and tested destinations.
8. Delete OCDI only after the import test passes.
