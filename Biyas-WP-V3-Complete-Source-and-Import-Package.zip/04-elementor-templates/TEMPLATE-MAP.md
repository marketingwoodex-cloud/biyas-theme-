# Elementor Template Map

Every `.json` file is a reference/import source corresponding to the same-name HTML reference template. All use Container, Heading, Text Editor, Button and Icon List only. Import one at a time for Option B. Header/Footer source JSON is then rebuilt/assigned in XPRO Theme Builder.
