# Biya’s Art Gallery — V3 Complete Build, Import & Manual Recovery Master Plan

**Status:** planning and package-structure phase only.  
**Goal:** produce a complete, traceable WordPress deployment folder containing a standalone Biya theme, optional child theme, one permanent master plugin, complete Elementor source templates, OCDI import assets, XPRO build source layouts, and a separate manual recovery option.

## 1. V3 decisions locked

- Build a standalone **Biya’s WP** theme; no Hello Elementor dependency.
- Elementor Free only: Containers and native free widgets only.
- Do not use Elementor Pro, HTML widgets, Atomic Elements or Inner Sections.
- XPRO is a separately installed free plugin. It is not bundled, modified or automatically assigned.
- OCDI is a temporary import tool. It may be removed only after the imported site passes verification.
- One permanent **Biya’s WP Master Plugin** handles content types, content rules, native editorial fields and controlled queries.
- No ACF package.
- No real media, fake artwork, invented folios, false events or invented biographies are imported.
- All imported pages, CPT records and source templates are Draft by default.
- Public founder label is **Biya Jee** only.

## 2. Required V3 folder structure

```text
assad-complete/
├── 00-master-plan/
│   └── MASTER_PLAN_V3.md
├── 01-option-a-ocdi-demo-import/
│   ├── biyas-wp-theme.zip
│   ├── biyas-wp-child.zip
│   ├── biyas-wp-master-plugin.zip
│   ├── demo-content/
│   │   ├── biya-v3-safe-draft-demo.xml
│   │   ├── elementor-kit-reference.json
│   │   ├── elementor-json/
│   │   └── README-OCDI-IMPORT.md
│   └── OPTION-A-OCDI-INSTALL.md
├── 02-option-b-manual-upload-recovery/
│   ├── theme-source/
│   ├── master-plugin-source/
│   ├── elementor-json/
│   ├── xpro-source-layouts/
│   ├── wordpress-content-xml/
│   ├── manual-checklists/
│   └── OPTION-B-MANUAL-INSTALL.md
├── 03-template-html-reference/
│   ├── home.html
│   ├── artworks.html
│   ├── artwork-single.html
│   ├── collections.html
│   ├── third-art.html
│   ├── biya-jee.html
│   ├── punjabi-verha.html
│   ├── events.html
│   ├── projects.html
│   ├── books.html
│   ├── press.html
│   ├── journal.html
│   ├── commissions.html
│   ├── trade.html
│   ├── visit-contact.html
│   ├── guide.html
│   ├── privacy.html
│   ├── terms.html
│   ├── header.html
│   ├── footer.html
│   └── README-HTML-REFERENCE.md
├── 04-elementor-templates/
│   ├── page-json/
│   ├── archive-json/
│   ├── single-json/
│   ├── global-source-json/
│   └── TEMPLATE-MAP.md
├── 05-xpro-manual/
│   ├── header-build-map.md
│   ├── footer-build-map.md
│   ├── xpro-library-save-checklist.md
│   └── xpro-display-conditions.md
├── 06-slider-plugin/
│   ├── biyas-editorial-slider.zip
│   ├── source/
│   └── README-SLIDER.md
├── 07-content-model-and-drafts/
│   ├── artwork-draft-schema.md
│   ├── collection-draft-schema.md
│   ├── artist-draft-schema.md
│   ├── event-draft-schema.md
│   ├── project-draft-schema.md
│   ├── book-draft-schema.md
│   ├── punjabi-verha-draft-schema.md
│   ├── press-item-draft-schema.md
│   └── journal-article-draft-schema.md
├── 08-qa-and-audit/
│   ├── package-audit.md
│   ├── import-test-log.md
│   ├── manual-recovery-log.md
│   ├── accessibility-qa.md
│   └── launch-gate.md
└── README-START-HERE.md
```

## 3. Option A — OCDI complete demo import

### Purpose
For the quickest safe setup on a clean staging site.

### User installation order
1. Backup the target site.
2. Upload and activate `biyas-wp-theme.zip`.
3. Upload and activate `biyas-wp-master-plugin.zip`.
4. Install Elementor Free.
5. Install OCDI temporarily from the supplied WordPress.org-compatible plugin.
6. Import **Biya’s WP — V3 Safe Draft Foundation** through Appearance → Import Demo Data.
7. Verify imported Draft pages, source layouts, menu and native content types.
8. Install XPRO manually.
9. Use the XPRO manual folder to turn Header/Footer source layouts into site-wide XPRO templates; save both into XPRO Library.
10. Activate the simple editorial slider plugin only after slider review.
11. Configure WPForms manually; no form destination is invented.
12. Complete QA; then deactivate/delete OCDI if the import test passes.

### What OCDI imports
- Draft structural pages.
- Draft CPT shell records only where a template test requires one. Every imported record is clearly marked Pending Verification and must remain unpublished.
- WordPress menu structure.
- Elementor page/source layout data created from a reference build.
- Neutral text-only holding states.
- No media download or remote media dependency.

## 4. Option B — manual upload / recovery package

### Purpose
Use this route if OCDI fails, a host blocks imports, Elementor version mismatch occurs, or a manual implementer needs to isolate the problem.

### Manual sequence
1. Upload theme ZIP.
2. Upload Master Plugin ZIP.
3. Install Elementor Free.
4. Import one Elementor JSON layout at a time, starting with Home.
5. Confirm a real Container appears before importing the next layout.
6. Import WXR only after theme/plugin are active.
7. Create Header and Footer manually in XPRO from the supplied source maps.
8. Use `import-test-log.md` to record every pass/failure, WordPress/PHP/plugin version and screenshot.

**Why Option B exists:** it isolates theme, plugin, WXR, Elementor JSON and XPRO problems rather than making the manual implementer guess which part failed.

## 5. Complete template design scope

Every page receives an HTML reference file, Elementor JSON source and import mapping. The visual system uses an editorial evergreen/champagne/gold palette, a maximum 1280px container and accessible buttons.

### Global source layouts
- Header: gallery brand, descriptor, navigation, private-viewing CTA, responsive menu specification.
- Footer: brand statement, explore links, collector services, legal links and conditional contact area.

### Home
1. Text-only editorial hero.
2. Brand proposition.
3. Art / Biya Jee / Punjabi Verha cultural pillars.
4. Artwork holding-state module.
5. The Third Art holding-state module.
6. Events holding-state module.
7. Private viewing CTA.

### Content and route templates
- Artworks archive and Artwork single.
- Collections archive and Collection single.
- Artist single.
- The Third Art archive.
- Biya Jee, Poetry/Writing, Books/Library and Media/Interviews.
- Punjabi Verha hub, event archive, Mushairas, Muqalma, Video and Media.
- Exhibitions and Events archive/single.
- Projects and Interiors archive/single.
- Commissions, Trade and Hospitality, Visit/Contact, Press, Journal, Guide, Privacy, Terms and 404.

## 6. Data model and draft content rules

The master plugin registers and validates:

| Content type | Import state | Publication requirement |
|---|---|---|
| Artwork | No real demo artwork. Optional shell record is Draft / Pending Verification. | Verified + approved rights |
| Collection | Draft shell only | Verified statement / rights |
| Artist | Draft shell only; public label rule remains Biya Jee | Verified bio/source |
| Event | Draft shell only, must use one allowed event type | Verified event details |
| Project | Draft shell only | Rights-approved documentation |
| Book | Draft shell only | Verified bibliography / rights |
| Punjabi Verha Event | Draft shell only | Verified programme/source |
| Press Item | Draft shell only | Verified outlet/source URL |
| Journal Article | Draft shell only | Verified editorial approval |

Required Event Type values:
- exhibition
- mushaira
- muqalma
- talk
- private-viewing
- other

Third Art folios remain Artwork CPT records with `art_type=third-art-folio`; they are never a separate CPT. The archive shows holding state until approved records exist.

## 7. Slider plugin — safe three-slide editorial sequence

A small custom plugin, `biyas-editorial-slider`, is created as a separate optional plugin.

### Rules
- No external slider library.
- No jQuery dependency.
- No remote calls.
- CSS transform/opacity animation only.
- Keyboard-accessible previous/next controls and pause control.
- Respects `prefers-reduced-motion`.
- Works with three text-only slides:
  1. **Biya’s Art Gallery** — Art | Poetry | Culture | Lahore
  2. **The Third Art** — Archive in careful preparation
  3. **Punjabi Verha** — Poetry, dialogue and gathering
- No visual work is claimed or displayed as real gallery media.

The plugin is separate because the user may later elect to use an external free slider plugin instead. It is not tied to XPRO or Elementor Pro.

## 8. External free plugin responsibilities

| Plugin | How V3 uses it | Bundled? |
|---|---|---|
| One Click Demo Import | Temporary import UI for Option A | No — manually installed, then removable |
| XPRO | Header/Footer Theme Builder and Library | No — manually installed and configured |
| Elementor Free | Editing Container layouts | No — manually installed |
| WPForms | Contact/inquiry forms | No — manually installed and configured |
| External Slider Hero plugin | Optional alternative to Biya editorial slider | No — user decision; not required |

## 9. V3 verification gates

### Package checks
- PHP lint each theme/plugin source file.
- XML well-formedness and WXR import test.
- JSON parse and Elementor Container/widget policy scan.
- ZIP integrity and file inventory scan.
- No prohibited HTML widget / Elementor Pro / Inner Section / Atomic Element reference.

### Clean-site Option A test
- New WordPress staging site.
- Activate theme + Master Plugin + Elementor + temporary OCDI.
- Import only once.
- Confirm all pages/CPT shells remain Draft.
- Confirm all imported layouts open with editable Containers.
- Confirm Header/Footer sources are present.
- Confirm no remote media request/failure occurs.

### Manual Option B test
- Import Home JSON first, then record result.
- Continue one template at a time.
- Test XPRO Header/Footer setup and library save.
- Use the failure log for any mismatch.

## 10. Build sequence after plan approval

1. Create the complete folder tree exactly as specified.
2. Copy existing audited source into V3 source folders, clearly labelling obsolete files.
3. Create full HTML visual reference pages without external media.
4. Convert each approved reference structure to Elementor Container JSON.
5. Build the standalone theme and optional child theme.
6. Refactor the single Master Plugin, including validation and data rules.
7. Build the text-only accessible three-slide plugin.
8. Generate a real WXR from a clean reference WordPress build, not hand-authored XML.
9. Integrate OCDI into the theme and prepare Option A.
10. Prepare Option B manual recovery kit.
11. Run package/clean-site/manual tests and record results.
12. Release V3 only after verification passes.

## 11. Non-negotiable publication gate

This package may create a complete visual shell, but it must not publish unverified cultural, artist, archive, event or artwork material. The full visual site can use holding states until the owner supplies verified content and rights approval.
