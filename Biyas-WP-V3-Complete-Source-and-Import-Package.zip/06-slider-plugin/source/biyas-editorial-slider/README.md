# Biya Editorial Slider

Optional, standalone, text-only slider. Activate and insert `[biyas_editorial_slider]` only after review. It does not use external libraries, media, Elementor Pro or HTML widgets. For Elementor, use the shortcode only through a permitted native shortcode integration; if this is not acceptable in the project, use the static three hero source containers instead.
