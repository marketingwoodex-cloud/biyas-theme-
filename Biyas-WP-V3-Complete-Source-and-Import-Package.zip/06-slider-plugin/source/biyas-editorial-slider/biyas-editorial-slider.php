<?php
/**
 * Plugin Name: Biya Editorial Slider
 * Description: A small, accessible, text-only three-slide hero for Biya's Art Gallery.
 * Version: 1.0.0
 */
if (!defined('ABSPATH')) exit;
add_action('wp_enqueue_scripts', function(){
 wp_register_style('biyas-editorial-slider',plugins_url('assets/slider.css',__FILE__),[], '1.0.0');
 wp_register_script('biyas-editorial-slider',plugins_url('assets/slider.js',__FILE__),[], '1.0.0',true);
});
add_shortcode('biyas_editorial_slider',function(){
 wp_enqueue_style('biyas-editorial-slider');wp_enqueue_script('biyas-editorial-slider');
 $slides=[["Biya’s Art Gallery","Art | Poetry | Culture | Lahore","Explore Artworks","/artworks/"],["The Third Art","Archive in careful preparation","Request Details","/the-third-art/"],["Punjabi Verha","Poetry, dialogue and gathering","Explore Punjabi Verha","/punjabi-verha/"]];
 ob_start(); ?><section class="bes" aria-label="Biya Gallery editorial highlights"><div class="bes__slides"><?php foreach($slides as $i=>$s): ?><article class="bes__slide<?php echo $i?'':' is-active'; ?>" aria-hidden="<?php echo $i?'true':'false'; ?>"><p class="bes__eyebrow">Biya’s Art Gallery</p><h2><?php echo esc_html($s[0]); ?></h2><p><?php echo esc_html($s[1]); ?></p><a href="<?php echo esc_url($s[3]); ?>" class="bes__cta"><?php echo esc_html($s[2]); ?></a></article><?php endforeach; ?></div><div class="bes__controls"><button type="button" class="bes__prev" aria-label="Previous slide">Previous</button><button type="button" class="bes__next" aria-label="Next slide">Next</button><button type="button" class="bes__pause" aria-pressed="false">Pause</button></div></section><?php return ob_get_clean();
});
