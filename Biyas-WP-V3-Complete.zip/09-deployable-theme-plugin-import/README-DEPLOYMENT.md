# Biya's Art Gallery V3 — Deployment Folder

## Required installation files
1. `theme/biyas-wp-v3-theme.zip`
2. `master-plugin/biyas-wp-v3-master-plugin.zip`
3. Elementor Free (manual install)
4. One Click Demo Import (temporary manual install)
5. XPRO (manual install)
6. WPForms (manual install)

## Import
Use `ocdi/biya-v3-safe-draft-demo.xml` only through the theme-registered OCDI demo after theme/plugin/Elementor are active. Do not import media because `media/` is intentionally empty pending rights approval.

## XPRO
`xpro-template-package/` contains actual Elementor global source JSON files plus the XPRO manifest and build maps. XPRO native exports cannot be safely generated without the exact installed XPRO version; create/assign the final templates in XPRO Theme Builder and save in its library.

## HTML reference
`html-reference/` contains all 33 V3 page/global HTML reference files and the shared design system. They are visual reference only, never HTML-widget content.
