# Media Folder — Rights Gate

This V3 import package intentionally includes **no public media files**.

Do not place generated slider visuals, programmed folio crops, watermarked references, downloaded social imagery, or unverified legacy assets into WordPress Media for publication.

Add a file here only after its source, copyright/license, subject identity, caption, destination page/CPT, alt text and verification status have been approved. Every published Artwork/Folio image must be linked to a Verified record with approved rights.
