# WPForms Build Map

Create these forms manually after the owner supplies the notification address/CRM destination:

1. Request Price / Details — artwork/folio, name, email, city, room context, timeline, consent.
2. Private Viewing — name, contact, preferred date, interest, consent.
3. Commission Brief — room type, dimensions, art type, palette, budget comfort, timeline, consent.
4. Trade Brief — company, project type, rooms, dimensions, budget, install date, consent.
5. Event RSVP — event, name, contact, access requirements, consent.

Enable spam protection, validation, consent, notification test and thank-you route. Insert only via the supported WPForms/Elementor integration; do not use an HTML widget.
