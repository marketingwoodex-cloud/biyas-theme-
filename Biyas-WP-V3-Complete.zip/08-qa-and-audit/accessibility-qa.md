# Accessibility QA

- Keyboard header/menu navigation
- Visible focus
- Button contrast
- Heading order
- Reduced motion slider behavior
- Mobile menu
- Form errors and labels
- Empty-state readability
