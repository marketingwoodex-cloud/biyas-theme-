# Launch Gate

Do not publish before XPRO Header/Footer assignment, WPForms delivery test, source/rights review, verified-only content check, redirect test and responsive/accessibility QA.
