# Biya’s Art Gallery V3 — Technical Testing, Round 01

**Date:** 23 August 2026  
**Test scope:** static/package validation in the available workspace.  
**Runtime constraint:** PHP, WordPress, Elementor, OCDI and XPRO are not installed/runnable in this workspace. This round cannot grant staging or production approval.

## Simple summary

- **Package files:** pass basic integrity checks.
- **Draft import data:** pass XML and consistency checks.
- **Slider JavaScript:** syntax check passed.
- **Theme/Master Plugin:** source exists, but PHP activation and WordPress behaviour are untested.
- **Critical data-rule bugs found:** Event and Third Art validation are not yet strong enough for production.
- **Decision:** Runtime/staging verification remains **PENDING**. Production publication remains **NOT GRANTED**.

## 1. Tests executed

| Test | Result | Evidence |
|---|---|---|
| Complete package ZIP integrity | Pass | ZIP test returned no compressed-data errors. |
| Option A ZIP integrity | Pass | ZIP test returned no compressed-data errors. |
| Option B ZIP integrity | Pass | ZIP test returned no compressed-data errors. |
| Elementor JSON parse | Pass | 33 JSON files parsed. |
| Elementor JSON policy scan | Pass | Generated files contain no legacy Section, HTML widget, Pro widget, Inner Section or Atomic Element reference. |
| WXR XML parse | Pass | V3 WXR file parsed successfully. |
| WXR draft status | Pass | 33/33 records are Draft: 31 pages, 2 Elementor Library records. |
| WXR copy consistency | Pass | Option A, Option B and parent-theme WXR copies have the same SHA-256 checksum. |
| HTML media/remote reference scan | Pass | No image, video or external URL reference in V3 HTML reference templates. |
| Slider JavaScript syntax | Pass | `node --check` passed on `slider.js`. |
| PHP lint | Not run | PHP binary is unavailable in this workspace. |
| WordPress/OCDI import | Not run | No WordPress runtime. |
| Elementor editor test | Not run | No Elementor runtime. |
| XPRO template assignment | Not run | No XPRO runtime. |

## 2. Bugs and blockers found

### B-01 — Third Art required folio image is not implemented
**Severity:** Critical  
**Source:** V3 Master Plugin native Artwork metabox and validation.

The governance model requires every approved Third Art folio Artwork record to include:

- `folio_number`
- `folio_image`
- `title_or_verse`
- `approved_translation`
- `archive_note`
- `rights_status`
- `verification_status`

The current plugin has UI/storage for folio number, title/verse, translation and archive note. It does **not** provide a `folio_image` media field or enforce it before publication.

**Fix required:** add native WordPress media uploader field, save attachment ID as `_bwp_folio_image`, and block publish for `art_type=third-art-folio` when missing.

### B-02 — Event Type validation is not reliable for a newly created Event
**Severity:** Critical  
**Source:** `wp_insert_post_data` validation method.

WordPress assigns taxonomy terms after the post data stage. The current validation calls `wp_get_object_terms()` during `wp_insert_post_data`; for newly created records this can see no term even when a term is being submitted, or it can miss the intended post-save state.

**Fix required:** move validation to a post-save/term-save workflow with a recursion guard, then force Draft and show admin notice if no valid allowed `event_type` exists.

### B-03 — Verified-only archive behaviour is not enforced in the Master Plugin
**Severity:** Critical  
**Source:** static plugin source review.

The plan requires only Verified / rights-approved content to publish through controlled dynamic archive queries. The current plugin registers types and fields but does not contain a robust `pre_get_posts` or template query restriction for Artwork, Third Art, Event and related archives.

**Fix required:** add controlled query rules and explicit archive helpers so frontend output accepts only `verification_status=verified` and approved rights where required. The Third Art query must additionally require `art_type=third-art-folio`.

### B-04 — Existing Elementor/WXR source is a foundation, not a full visual translation
**Severity:** High  
**Source:** source comparison.

The 33 HTML reference files have richer visual hierarchy than their corresponding generated JSON/WXR layouts. The generated Elementor data currently consists mainly of a hero and a holding-state container. This is structurally valid but does not yet recreate every HTML reference section.

**Fix required:** expand each JSON/WXR template to include the full approved section hierarchy: hero, editorial content, cultural pillars, CTAs, holding modules, legal/utility elements and global source layouts.

### B-05 — XPRO Header/Footer are source/manual only
**Severity:** High

There are Header/Footer source layouts and complete manual instructions, but no live XPRO assignment can be packaged because XPRO is user-installed and target-site-specific.

**Fix required:** manual staging implementation: create Header/Footer in XPRO Theme Builder, set Entire Site conditions and save to XPRO Library; capture screenshots and test navigation/mobile behaviour.

### B-06 — Slider links are placeholders
**Severity:** Medium

The slider has accessible controls and passes JavaScript syntax, but its three CTA links use `#`.

**Fix required:** map slides to approved final routes before enabling the plugin:
- Artworks → `/artworks/`
- Third Art → `/the-third-art/` or approved final route
- Punjabi Verha → `/punjabi-verha/`

### B-07 — Elementor version marker is a compatibility risk
**Severity:** Medium

The WXR builder data uses `_elementor_version = 3.x`, which is a generic marker rather than an exact version generated by the target Elementor installation.

**Fix required:** after the first clean staging build, export a genuine WXR from that exact WordPress/Elementor environment and replace this reference WXR with the actual export.

## 3. No-fault observations

- The blank checkerboard OCDI preview is expected because the project intentionally has no media preview image.
- WPForms, All in One SEO and MonsterInsights shown by OCDI are generic recommendations; they are not required for the V3 import. Do not select unrelated plugins merely because OCDI lists them.
- Imported event/artwork/collection posts are intentionally absent; importing unverified cultural records would violate the project publication rules.

## 4. Required next technical work

1. Fix B-01, B-02 and B-03 in the Master Plugin.
2. Expand Elementor JSON and WXR layouts to match the full HTML reference hierarchy (B-04).
3. Map slider links to approved routes (B-06).
4. Rebuild all three V3 ZIP packages.
5. Run a clean staging runtime test.
6. Create/assign XPRO Header and Footer manually in staging.
7. Only then run final publication QA.

## 5. Current gate

**Runtime/staging verification: PENDING.**  
**Production publication approval: NOT GRANTED.**
