# Biya’s Art Gallery V3 — Technical Testing, Round 02 Fix Report

**Date:** 23 August 2026  
**Purpose:** remediation of source-level defects B-01 to B-06 from Technical Testing Round 01.

## Fixes completed

| Prior issue | Fix applied | Static result |
|---|---|---|
| B-01: no folio image | Added native WP media uploader button/attachment field stored as `_bwp_folio_image`; added it to Third Art publication requirements. | Source updated; staging test required. |
| B-02: Event Type validation too early | Removed the early post-data validation path and added post-save validation using `wp_after_insert_post`, a recursion guard and admin error transient. | Source updated; staging test required. |
| B-03: verified-only dynamic artwork filter absent | Added main Artwork query filter for `_bwp_verification=verified` and `_bwp_rights=approved`; added a verified Third Art query helper constrained to Artwork + `art_type=third-art-folio` + verified/approved meta. | Source updated; staging test required. |
| B-04: JSON/WXR foundation too thin | Expanded each page JSON/WXR page layout to five Container sections: hero, editorial context, page-specific content structure, holding state and private-conversation conversion. | 31 page layouts now contain five top-level Containers. |
| B-05: XPRO manual source | No code fix possible or appropriate. XPRO remains a manual, target-site-specific build/assignment task. | Documentation remains complete. |
| B-06: slider `#` links | Mapped slide CTAs to `/artworks/`, `/the-third-art/` and `/punjabi-verha/`. | Source updated; target-route test required. |

## Static checks passed after fixes

- 33 Elementor JSON files parse successfully.
- 31 page JSON layouts contain five top-level Containers.
- The two global source JSON layouts remain intentionally one Container each.
- Rebuilt WXR XML parses successfully.
- All 33 WXR records remain Draft.
- Slider JavaScript syntax remains valid.
- Complete V3 ZIP integrity test passed after package rebuild.

## Remaining mandatory runtime tests

The following still cannot be verified in this workspace:

1. PHP lint / theme and plugin activation.
2. WordPress `wp_after_insert_post` validation behaviour on new Event / Third Art records.
3. Native WordPress media selector functionality for folio image.
4. OCDI import of the rebuilt WXR on an empty WordPress site.
5. Elementor’s acceptance/editability of imported five-Container layouts.
6. XPRO Header/Footer assignment and Library save.
7. Form, accessibility, mobile, redirect and launch QA.

## Current gate

**Runtime/staging verification: PENDING.**  
**Production publication approval: NOT GRANTED.**
