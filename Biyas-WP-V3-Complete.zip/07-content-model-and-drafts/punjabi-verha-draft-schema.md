# Punjabi Verha Draft Schema

Draft import state: Pending Verification / not public.

Punjabi Verha Event: programme, required event_type, guest, date, venue, sources, RSVP and verification status.
