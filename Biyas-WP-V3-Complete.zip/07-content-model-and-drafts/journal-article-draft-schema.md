# Journal Article Draft Schema

Draft import state: Pending Verification / not public.

Journal Article: title, author, date, body, category and verification status.
