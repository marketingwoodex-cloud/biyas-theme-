# Project Draft Schema

Draft import state: Pending Verification / not public.

Project: title, statement, year, documentation, approved media/rights and verification status.
