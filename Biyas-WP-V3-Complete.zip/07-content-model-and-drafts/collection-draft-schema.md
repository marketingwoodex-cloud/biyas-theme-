# Collection Draft Schema

Draft import state: Pending Verification / not public.

Collection: title, approved curatorial statement, verified cover/right status. Public label Collection; taxonomy is artwork_collection only.
