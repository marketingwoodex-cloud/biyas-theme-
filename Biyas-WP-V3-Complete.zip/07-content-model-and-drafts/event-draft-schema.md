# Event Draft Schema

Draft import state: Pending Verification / not public.

Event: required event_type (exhibition, mushaira, muqalma, talk, private-viewing, other), date, time, venue, guests, programme, RSVP mode and verification status.
