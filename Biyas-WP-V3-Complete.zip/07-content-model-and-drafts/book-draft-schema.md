# Book Draft Schema

Draft import state: Pending Verification / not public.

Book: title, author, publication year, language, synopsis, approved excerpt, availability and verification status.
