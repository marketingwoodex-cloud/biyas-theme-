# Press Item Draft Schema

Draft import state: Pending Verification / not public.

Press Item: outlet, date, source URL, verified summary, related item and verification status.
