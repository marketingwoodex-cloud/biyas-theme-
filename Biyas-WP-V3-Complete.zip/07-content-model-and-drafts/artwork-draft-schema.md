# Artwork Draft Schema

Draft import state: Pending Verification / not public.

Artwork: title, verification_status, rights_status, artist_profile (Artist CPT relation), artwork_collection, medium, art_type, dimensions, availability, price_policy. Original artworks are enquiry-only. Third Art adds folio_number, folio_image, title_or_verse, approved_translation and archive_note.
