# Artist Draft Schema

Draft import state: Pending Verification / not public.

Artist: public display name, biography, practice, approved source URLs and verification status. Founder frontend label is Biya Jee until official spelling approval.
