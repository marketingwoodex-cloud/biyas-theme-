# Biya’s Art Gallery V3 — Pending Development Completion Master Plan

**Purpose:** close every remaining file/package-development task identified in the conversion and technical audit, while separating deliverables that can be generated in the workspace from tasks that require a live WordPress/XPRO/Elementor staging site or owner-supplied verified media/content.

## 1. Completion categories

### A. Completed file/package development

| Requirement | Deliverable | Status |
|---|---|---|
| Standalone V3 parent theme | `09-deployable-theme-plugin-import/theme/biyas-wp-v3-theme.zip` | Complete |
| Optional child theme | `09-deployable-theme-plugin-import/child-theme/biyas-wp-v3-child.zip` | Complete |
| One permanent Master Plugin | `09-deployable-theme-plugin-import/master-plugin/biyas-wp-v3-master-plugin.zip` | Complete |
| OCDI source | `09-deployable-theme-plugin-import/ocdi/biya-v3-safe-draft-demo.xml` | Complete |
| Elementor page/global sources | `09-deployable-theme-plugin-import/elementor-templates/` | Complete: 33 JSON sources |
| Full HTML visual references | `09-deployable-theme-plugin-import/html-reference/` | Complete: 33 HTML files + design CSS |
| XPRO source package | `09-deployable-theme-plugin-import/xpro-template-package/` | Complete: 2 JSON source layouts + manifest + manual maps |
| Slider source | `06-slider-plugin/biyas-editorial-slider.zip` | Complete: optional text-only component |
| Content schemas | `07-content-model-and-drafts/` | Complete: 9 model schemas |
| Manual recovery route | `02-option-b-manual-upload-recovery/` | Complete |
| Rights-safe media folder | `09-deployable-theme-plugin-import/media/` | Complete and intentionally empty |
| WPForms build plan | `09-deployable-theme-plugin-import/wpforms/WPFORMS_BUILD_MAP.md` | Complete |

### B. Not generatable without owner input or live staging

| Requirement | Dependency | Status |
|---|---|---|
| Approved hero / artwork / archive media | Owner-supplied rights-approved files | Waiting for assets |
| Real Artwork, Collection, Artist, Event, Project, Book, Punjabi Verha, Press and Journal records | Verified source and content approval | Waiting for content |
| WPForms notification destination | Owner-approved inbox / CRM | Waiting for owner input |
| XPRO native active Header/Footer templates | Exact installed XPRO runtime | Requires staging build |
| Elementor/OCDI import confirmation | WordPress/PHP/Elementor staging runtime | Requires staging test |
| Redirect/server/SEO/security validation | Target hosting/WordPress runtime | Requires staging test |

## 2. Media implementation rule

The V3 media folder is intentionally empty. This is not a missing-build defect.

The legacy project contains images, but the current governance rules do not allow automatic migration of generated visuals, programmed folio crops, unverified reference images or media with unresolved rights. Adding such media merely to make the demo look populated would violate the project requirements.

When owner-approved files arrive, add them using this media intake order:

1. Original file and filename.
2. Source/photographer/artist/owner.
3. Rights status = Approved.
4. Verification status = Verified.
5. Public caption and alt text.
6. Exact WordPress destination: Artwork, Third Art folio, Project, Book, Event, Press or page.
7. Image dimensions/crop approval.
8. Upload to Media Library and connect only to its approved CPT/page.

## 3. XPRO completion plan

The package now contains actual Elementor source JSON files:

- `global-header-source.json`
- `global-footer-source.json`

It also contains `xpro-template-manifest.json` and exact setup documentation. A true active XPRO export cannot be fabricated reliably outside the target XPRO installation because XPRO stores version/plugin-specific builder and display-condition data.

### Target-site XPRO finish steps
1. Install XPRO.
2. Import global source JSON into Elementor Saved Templates.
3. XPRO → Theme Builder → Add Header.
4. Insert/rebuild Header source with Container/native free/XPRO elements.
5. Assign **Entire Site**.
6. Save as `Biya’s Art Gallery | Global Header` to XPRO Library.
7. Repeat for Footer.
8. Disable/avoid duplicate standalone theme header/footer.
9. Test desktop, mobile, keyboard, menu focus and focus return.

## 4. HTML to Elementor completion plan

The `html-reference/` folder contains all 33 V3 reference files. It is not for use in an HTML widget.

For each route:

1. Use the matching JSON source as the initial Elementor layout.
2. Build/extend the same Container hierarchy from the matching HTML reference.
3. Use only native free widgets: Container, Heading, Text Editor, Button, Image/Image Gallery only once approved media exists, Icon List, Accordion and Divider.
4. Keep the holding-state section until approved records are available.
5. Replace `#` reference CTAs with final WordPress routes or tested WPForms integration.

## 5. Runtime acceptance plan

### Phase 1 — install
- Activate V3 parent theme.
- Activate V3 Master Plugin.
- Install Elementor Free.
- Install temporary OCDI.

### Phase 2 — import
- Appearance → Import Demo Data.
- Import `Biya’s WP — V3 Safe Draft Foundation` exactly once.
- Confirm 31 route pages and 2 source templates are created as Draft.
- Confirm no artwork/event/media records are published.

### Phase 3 — builder
- Edit Home, Artworks, Third Art, Biya Jee, Punjabi Verha, Events and a single template in Elementor.
- Confirm editable Containers, Heading, Text Editor and Buttons.
- Confirm no HTML widgets, Inner Sections, Atomic Elements or Pro widgets.

### Phase 4 — data model
- Test Event without event type → must return to Draft.
- Test Event with one allowed type → may proceed after governance fields are approved.
- Test Third Art Artwork without image → must return to Draft.
- Test completed Third Art Artwork with Verified + approved rights → eligible for controlled archive query.

### Phase 5 — global layout and forms
- Build XPRO Header/Footer, assign Entire Site and save to Library.
- Create WPForms and test email delivery/consent/spam controls.
- Enable WhatsApp only after official number approval.

### Phase 6 — launch
- Configure final menu and static homepage.
- Add/test 301 redirects from every old `.html` URL.
- Perform accessibility/responsive/SEO/security/backup tests.
- Publish only Verified, rights-approved content.

## 6. Definition of development completion

### Package development — complete
The V3 theme, plugin, OCDI source, HTML references, Elementor JSON, XPRO source package, manual recovery package, no-media rights gate and QA documentation are present.

### Operational website — not complete until the runtime acceptance plan passes
No report may claim that XPRO is active, Elementor conversion is live, forms send mail or a production website is published until the target-site tests are recorded.

**Runtime/staging verification: PENDING.**  
**Production publication approval: NOT GRANTED.**
