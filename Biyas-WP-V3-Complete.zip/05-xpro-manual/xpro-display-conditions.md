# XPRO Display Conditions
Set Header and Footer to **Entire Site** after import. Exclude any temporary test pages if required. XPRO is installed manually and not bundled. Elementor Pro Theme Builder is not used.
