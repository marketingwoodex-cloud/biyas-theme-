# XPRO Library Checklist
- Header and Footer each created in XPRO Theme Builder.
- Correct site-wide display condition set.
- No duplicate theme fallback header/footer remains.
- Header/Footer each saved to XPRO Library.
- Desktop, tablet, mobile and keyboard checks recorded.
