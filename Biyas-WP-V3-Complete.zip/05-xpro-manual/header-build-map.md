# XPRO Header Build Map
1. XPRO → Theme Builder → Add New → Header.
2. Add one root Container; set full width, evergreen background and 18px/32px padding.
3. Add brand Container: Heading `Biya’s Art Gallery`, Text Editor descriptor `Art | Poetry | Culture | Lahore`.
4. Add WordPress/XPRO menu widget connected to the Primary Menu; do not use Elementor Pro Nav Menu.
5. Add native Button: `Arrange a Private Viewing` → `/visit-contact/`.
6. Add responsive mobile menu using XPRO’s free menu capability; test keyboard focus/Escape.
7. Display Condition: Entire Site.
8. Save as `Biya’s Art Gallery | Global Header` in XPRO Library.
