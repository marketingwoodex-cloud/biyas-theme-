# XPRO Footer Build Map
1. XPRO → Theme Builder → Add New → Footer.
2. Add root evergreen Container and three responsive child Containers.
3. Column 1: gallery name and `Not decoration. A presence.`
4. Column 2: Explore links.
5. Column 3: Request Price, Request Details and Private Viewing links.
6. Add legal row: Privacy, Terms, Commission Policy and Delivery/Returns when approved.
7. Do not add unverified address, email, phone, social accounts or map.
8. Display Condition: Entire Site.
9. Save as `Biya’s Art Gallery | Global Footer` in XPRO Library.
