# Original Static HTML — Non-Conversion Source Folder

This folder preserves the pre-V3 static website source for review and manual conversion planning only.

It is not a deployment theme, not an Elementor template package and not approved publication content.

Do not import its assets into the WordPress Media Library as gallery artwork, event, archive or folio media without separate source/rights/verification approval.

Contents are organized as:
- `pages/` — 15 original HTML pages
- `styles/` — original `style.css`
- `scripts/` — original `app.js`
- `assets/` — legacy local asset files retained only for audit/reference
