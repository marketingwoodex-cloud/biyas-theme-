# Original HTML Page and Section Inventory

| Page | Sections | Section identifiers |
|---|---:|---|
| `b2b.html` | 3 | page-hero third-hero, trade section, trade-brief#brief |
| `collections.html` | 4 | collection-hero, collection-toolbar, catalogue-grid#catalogue, catalogue-note |
| `custom-studio.html` | 2 | page-hero third-hero, studio section#brief |
| `events.html` | 5 | events-hero, events-intro section, programs section#programs, future-program, rsvp-section#rsvp |
| `faq.html` | 4 | faq-hero, faq-guide section, faq-area, faq-final |
| `founder.html` | 7 | founder-hero, section bio, poetry-strip#poetry, process, timeline section, sources section, contact founder-contact |
| `gallery.html` | 2 | page-hero third-hero, portfolio-grid |
| `index.html` | 8 | cinema-hero#top, opening-scene#opening-scene, craft-scene, collection-reveal, poetry-scene, biya-portrait-scene, services-drift, home-final |
| `journal.html` | 5 | journal-hero, journal-feature, journal-list section, journal-video, journal-signup |
| `poetry.html` | 5 | poetry-hero, poetry-intro section, poem-index section, poetry-note-band, contact poetry-contact |
| `portfolio.html` | 4 | portfolio-hero, portfolio-intro section, portfolio-grid#works, portfolio-cta |
| `product.html` | 1 | product-detail |
| `services.html` | 6 | services-hero, service-intro section, service-list#services, commission-scene, service-proof section, service-contact#contact |
| `third-art.html` | 6 | page-hero third-hero, section premise, art-language, archive-surah#archive, quote-band, section research-note |
| `visit.html` | 5 | visit-hero, visit-intro section, visit-options, visit-ritual, appointment-section#appointment |

**Total original HTML pages:** 15
**Total original `<section>` elements:** 67

This is a source inventory only; it does not approve claims, assets or records for WordPress publication.